function About() {
  return (
    <>
      <h1>This is About</h1>
      <h2>"your journey your story"</h2>
      <h3>"Choose your favourite Destination"</h3>
    </>
  );
}

export default About;
