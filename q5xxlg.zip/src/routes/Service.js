function Service() {
  return (
    <>
      <h1>This is Service</h1>
      <div><p>Flight Booking</p></div>
      <h2>departure</h2>
       <h3>       

       </h3>
       <h2>one way or round trip</h2>

      <h2>arrival</h2>
      <h2>departure date</h2>
      <h2>Travellers   & cabin Class</h2>
      <h2>special fares & promocode</h2>
      <h2>show non-stop flight only</h2>
      <h2>search Flights</h2>
      
    </>
  );
}

export default Service;
