import Navbar from "../components/Navbar";

function Home() {
  return (
    <>
      <Navbar />
      <h1>This is Home</h1>
    </>
  );
}

export default Home;
