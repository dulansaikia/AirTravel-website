export const MenuItems = [
  {
    title: "Home",
    url: "/",
    cName: "nav-links"
  },
  {
    title: "About",
    url: "/about",
    cName: "nav-links"
  },
  {
    title: "Service",
    url: "/service",
    cName: "nav-links"
  },
  {
    title: "Sign Up",
    url: "/signup",
    cName: "nav-links-mobile"
  }
];
