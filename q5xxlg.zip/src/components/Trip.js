import ".TripStyle.css";
function Trip() {
  return (
    <div className="trip">
      <h1>discover trips</h1>
    </div>
  );
}
export default Trip;
